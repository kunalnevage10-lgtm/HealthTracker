import sqlite3
from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# --- DBMS Setup ---
def init_db():
    conn = sqlite3.connect('healthsync.db')
    cursor = conn.cursor()
    # User Profile Table
    cursor.execute('''CREATE TABLE IF NOT EXISTS USER 
                      (UserID INTEGER PRIMARY KEY AUTOINCREMENT, Name TEXT, Age INTEGER, Weight REAL, Daily_Goals INTEGER)''')
    # Activity & Hydration Tables
    cursor.execute('''CREATE TABLE IF NOT EXISTS ACTIVITY_LOG 
                      (id INTEGER PRIMARY KEY AUTOINCREMENT, steps INTEGER, date TEXT, UserID INTEGER)''')
    cursor.execute('''CREATE TABLE IF NOT EXISTS HYDRATION_LOG 
                      (id INTEGER PRIMARY KEY AUTOINCREMENT, water INTEGER, timestamp TEXT, UserID INTEGER)''')
    conn.commit()
    conn.close()

@app.route('/')
def dashboard():
    conn = sqlite3.connect('healthsync.db')
    cursor = conn.cursor()
    cursor.execute("SELECT Name, Daily_Goals FROM USER ORDER BY UserID DESC LIMIT 1")
    user = cursor.fetchone()
    
    # Fetching History
    cursor.execute("SELECT steps, date FROM ACTIVITY_LOG ORDER BY id DESC LIMIT 5")
    step_history = cursor.fetchall()
    cursor.execute("SELECT water, timestamp FROM HYDRATION_LOG ORDER BY id DESC LIMIT 5")
    water_history = cursor.fetchall()
    conn.close()
    
    if not user: return redirect(url_for('login'))
    return render_template('index.html', user=user, step_history=step_history, water_history=water_history)

@app.route('/login')
def login(): return render_template('login.html')

@app.route('/setup_profile', methods=['POST'])
def setup_profile():
    name, age = request.form.get('name'), request.form.get('age')
    weight, goals = request.form.get('weight'), request.form.get('goals')
    conn = sqlite3.connect('healthsync.db')
    cursor = conn.cursor()
    cursor.execute("INSERT INTO USER (Name, Age, Weight, Daily_Goals) VALUES (?, ?, ?, ?)", (name, age, weight, goals))
    conn.commit()
    conn.close()
    return redirect(url_for('dashboard'))

@app.route('/sync', methods=['POST'])
def sync():
    steps = request.form.get('steps')
    water = request.form.get('water')
    conn = sqlite3.connect('healthsync.db')
    cursor = conn.cursor()
    if steps: cursor.execute("INSERT INTO ACTIVITY_LOG (steps, date, UserID) VALUES (?, date('now'), 1)", (steps,))
    if water: cursor.execute("INSERT INTO HYDRATION_LOG (water, timestamp, UserID) VALUES (?, datetime('now'), 1)", (water,))
    conn.commit()
    conn.close()
    return redirect(url_for('dashboard'))

if __name__ == '__main__':
    init_db()
    app.run(debug=True)