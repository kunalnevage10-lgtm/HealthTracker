import sqlite3

# --- OOPs Implementation: Database Manager ---
class DBManager:
    def __init__(self, db_name='healthtracker.db'):
        self.db_name = db_name
        self.init_db()

    def init_db(self):
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()
        # SQLite Syntax Fix: AUTOINCREMENT (No underscore)
        cursor.execute('''CREATE TABLE IF NOT EXISTS ACTIVITY_LOG 
                          (id INTEGER PRIMARY KEY AUTOINCREMENT, steps INTEGER, date TEXT)''')
        cursor.execute('''CREATE TABLE IF NOT EXISTS HYDRATION_LOG 
                          (id INTEGER PRIMARY KEY AUTOINCREMENT, water INTEGER, timestamp TEXT)''')
        conn.commit()
        conn.close()

    def save_data(self, steps, water):
        try:
            conn = sqlite3.connect(self.db_name)
            cursor = conn.cursor()
            cursor.execute("INSERT INTO ACTIVITY_LOG (steps, date) VALUES (?, date('now'))", (steps,))
            cursor.execute("INSERT INTO HYDRATION_LOG (water, timestamp) VALUES (?, datetime('now'))", (water,))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            print(f"Database Error: {e}")
            return False